The following files were generated for 'clk_gen' in directory 
E:\Verilog Projects\Exercises\rAVR\Xilinx\rtl\verilog\ver1.0\rAVR\ipcore_dir\

clk_gen_readme.txt:
   Text file indicating the files generated and how they are used.

clk_gen_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

clk_gen_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

